"""
Bonus: lightweight smoke tests for run.py's validation logic and
determinism, run with: pytest test_run.py -v
(No pytest install required to use the main pipeline -- this file is
optional and only exercised if you choose to run it.)
"""
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

RUN_PY = str(Path(__file__).parent / "run.py")
CONFIG = str(Path(__file__).parent / "config.yaml")
DATA = str(Path(__file__).parent / "data.csv")


def run_cli(input_path, config_path, tmp_path, name="t"):
    out = tmp_path / f"{name}_metrics.json"
    log = tmp_path / f"{name}_run.log"
    result = subprocess.run(
        [sys.executable, RUN_PY,
         "--input", str(input_path), "--config", str(config_path),
         "--output", str(out), "--log-file", str(log)],
        capture_output=True, text=True,
    )
    metrics = json.loads(out.read_text()) if out.exists() else None
    return result, metrics, log


def test_success_path(tmp_path):
    result, metrics, log = run_cli(DATA, CONFIG, tmp_path, "success")
    assert result.returncode == 0
    assert metrics["status"] == "success"
    assert metrics["rows_processed"] == 10000
    assert metrics["metric"] == "signal_rate"
    assert 0.0 <= metrics["value"] <= 1.0
    assert metrics["seed"] == 42
    assert log.exists() and log.stat().st_size > 0
    # stdout must be exactly the metrics JSON (nothing else)
    assert json.loads(result.stdout.strip()) == metrics


def test_determinism(tmp_path):
    _, m1, _ = run_cli(DATA, CONFIG, tmp_path, "run1")
    _, m2, _ = run_cli(DATA, CONFIG, tmp_path, "run2")
    assert m1["value"] == m2["value"]
    assert m1["rows_processed"] == m2["rows_processed"]


def test_missing_input_file(tmp_path):
    result, metrics, _ = run_cli(tmp_path / "missing.csv", CONFIG, tmp_path, "missing")
    assert result.returncode != 0
    assert metrics["status"] == "error"
    assert "not found" in metrics["error_message"].lower()


def test_missing_close_column(tmp_path):
    bad_csv = tmp_path / "bad.csv"
    pd.DataFrame({"open": [1, 2], "high": [1, 2]}).to_csv(bad_csv, index=False)
    result, metrics, _ = run_cli(bad_csv, CONFIG, tmp_path, "badcol")
    assert result.returncode != 0
    assert metrics["status"] == "error"
    assert "close" in metrics["error_message"].lower()


def test_empty_input_file(tmp_path):
    empty_csv = tmp_path / "empty.csv"
    empty_csv.touch()
    result, metrics, _ = run_cli(empty_csv, CONFIG, tmp_path, "empty")
    assert result.returncode != 0
    assert metrics["status"] == "error"


def test_invalid_config_missing_fields(tmp_path):
    bad_config = tmp_path / "bad_config.yaml"
    bad_config.write_text("seed: 42\n")
    result, metrics, _ = run_cli(DATA, bad_config, tmp_path, "badconfig")
    assert result.returncode != 0
    assert metrics["status"] == "error"
    assert "window" in metrics["error_message"] or "version" in metrics["error_message"]
