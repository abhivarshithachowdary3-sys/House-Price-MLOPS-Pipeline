import numpy as np
import pandas as pd

# Deterministic synthetic OHLCV dataset (10,000 rows) matching the spec's schema.
# NOTE: this is a placeholder generated because the real data.csv (Google Sheet)
# could not be downloaded from this sandbox. Swap in the real file before
# final submission -- run.py only depends on a `close` column existing.
rng = np.random.default_rng(42)
n = 10000

dates = pd.date_range("2020-01-01", periods=n, freq="min")
returns = rng.normal(loc=0.0, scale=0.001, size=n)
close = 100 * np.exp(np.cumsum(returns))

open_ = np.empty(n)
open_[0] = close[0]
open_[1:] = close[:-1]

high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.0008, n)))
low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.0008, n)))
volume = rng.integers(1000, 50000, n)

df = pd.DataFrame({
    "timestamp": dates,
    "open": open_.round(4),
    "high": high.round(4),
    "low": low.round(4),
    "close": close.round(4),
    "volume": volume,
})

df.to_csv("data.csv", index=False)
print(df.shape)
print(df.head())
